package Virtual_Key;


import java.io.File;
import java.io.IOException;

public class displayFile {
void display() {
String path="D:\\Sample\\";
    File f=new File(path);
File filenames[]=f.listFiles();
for(File ff:filenames) {
System.out.println(ff.getName());
}

}
}

