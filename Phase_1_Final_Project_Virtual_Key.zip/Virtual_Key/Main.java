package Virtual_Key;

import java.io.File;
import java.io.IOException;
import java.util.*;
public class Main {
public static void main(String[] args) throws IOException {
Scanner sc=new Scanner(System.in);
int ex;
displayFile obj=new displayFile();
addFile obj1=new addFile();
deleteFile obj2=new deleteFile();
searchFile obj3=new searchFile();

do {
System.out.println("Operation to be performed \n1.DisplayFile \n2.Other Operstions ");
int n=sc.nextInt();

switch(n){
case 1:
obj.display();
break;
case 2:do {
System.out.println("Enter the operation to be performed \n1.AddFile \n2.DeleteFile \n3.SearchFile");
int Op=sc.nextInt();
switch(Op) {
       case 1:
       obj1.add();
       break;
       case 2:
            obj2.delete();
            break;
       case 3:
            obj3.search();
            break;


}
System.out.println("Do you want to continue?1.Yes 2.No");
ex=sc.nextInt();
}while(ex==1);

}
System.out.println("Do you want to continue?1.Yes 2.No");
ex=sc.nextInt();

}while(ex==1);
}
}


