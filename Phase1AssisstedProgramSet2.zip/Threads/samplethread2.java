package Threadprgm;

public class samplethread2 extends Thread {

	public void run()
	{
		System.out.println("\nThread Name is"+" "+Thread.currentThread().getName());
		System.out.println("\nThread Priority is"+" "+Thread.currentThread().getPriority());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		samplethread2 s2=new samplethread2();
		s2.setName("My Thread");
		s2.setPriority(MAX_PRIORITY);
		s2.start();
		

	}

}
