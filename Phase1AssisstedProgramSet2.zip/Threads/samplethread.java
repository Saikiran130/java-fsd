package Threadprgm;

public class samplethread extends Thread{

	public void run()
	{
		System.out.println("\nThread is started...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		samplethread s1=new samplethread();
		s1.start();

	}

}
