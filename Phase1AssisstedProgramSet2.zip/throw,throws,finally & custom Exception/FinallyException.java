package ExceptionHandling;

public class FinallyException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]={12,13,14,15,16};
		
		try{
			int n=arr[6];
		}
		finally{
			System.out.println("\nThe exception is occured Catch block is not present ");
			System.out.println("\nThis block will execute even exception occur or not");
		}
		

	}

}
