package ExceptionHandling;

import java.util.Scanner;

public class ThrowException {
	static void get_grade(int a, int b)
	{
		if(b==0)
		{
			throw new ArithmeticException("\nDivide by Zero is not Possible");
		}
		else{
			System.out.println("\nResults are: "+(a/b));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowException t1=new ThrowException();
		Scanner s=new Scanner(System.in);
		int n1,n2;
		System.out.println("\nEnter the first number");
		n1=s.nextInt();
		System.out.println("\nEnter the second number");
		n2=s.nextInt();
		
		try{
			get_grade(n1,n2);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		

	}

}
