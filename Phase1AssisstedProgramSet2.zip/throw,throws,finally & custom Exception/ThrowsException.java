package ExceptionHandling;


import java.io.IOException;
import java.util.Scanner;

public class ThrowsException {
	
	static int display(int l, int b)throws IOException
	{
		int res=0;
		if(l>b)
		{
			System.out.println("\nException has Occurred");
			throw new IOException("\nLength is greater than breadth");
		}
		else{
			System.out.println("\nException is not occured");
		}
		return l*b;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThrowsException t1=new ThrowsException();
		Scanner s=new Scanner(System.in);
		int l,b;
		System.out.println("\nEnter the length & breadth");
		l=s.nextInt();
		b=s.nextInt();
		int result=0;
		try{
			result=display(l, b);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		System.out.println("\nResult is "+result);
		
		

	}

}

