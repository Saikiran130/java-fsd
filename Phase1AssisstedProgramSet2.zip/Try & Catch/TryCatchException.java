package ExceptionHandling;

import java.util.Scanner;

public class TryCatchException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n1,n2;
		System.out.println("\nEnter the First Number");
		n1=s.nextInt();
		System.out.println("\nEnter the second number");
		n2=s.nextInt();
		try{
                int divide=n1/n2;
                System.out.println("\nDivision Of Two Numbers"+" "+n1+" "+n2+" "+"are"+" "+divide);
            
		
        }catch(ArithmeticException e){
            System.out.println("Divide by zero exception!");
		

	}
	}
}


