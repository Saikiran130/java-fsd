package Threadprgm;

class table{
	synchronized public void get_table(int n)
	{
		for(int i=1;i<=n;i++)
		{
		System.out.println(Thread.currentThread().getName()+" "+(n*i));
		try{
			Thread.sleep(300);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		}
	}
}

class thread1 extends Thread{
	table t;
	thread1(table t)
	{
		this.t=t;
	}
	
	public void run()
	{
		t.get_table(5);
	}
}

class thread2 extends Thread{
	table t;
	thread2(table t)
	{
		this.t=t;
	}
	
	public void run()
	{
		t.get_table(4);
	}
}



public class ThreadSynchronized {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		table obj=new table();
		
		thread1 t1=new thread1(obj);
		thread2 t2=new thread2(obj);
		
		t1.setName("Thread 1");
		t2.setName("Thread 2");
		
		t1.start();
		t2.start();
		
		

	}

}
