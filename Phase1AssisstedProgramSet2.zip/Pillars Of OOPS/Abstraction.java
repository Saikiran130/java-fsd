package Assisted_Practice_2;

abstract class MNC{
	MNC(){
		System.out.println("\nParent class MNC");
	}
	abstract void compname();
	abstract void comploc();
	
	public void display1()
	{
		System.out.println("\nDsiplay method in MNC");
	}
	
}

abstract class infosys extends MNC{
	void compname(){
		System.out.println("\nCompany name is Infosys");
	}
	abstract void comploc();
}

class hello extends infosys{
	
	void comploc(){
		System.out.println("\nmethod 2 in hello class");
	}
	
	public void display()
	{
		System.out.println("\nDisplay method in hello class");
	}
}



public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MNC m1=new hello();
		
		
		m1.compname();
		m1.comploc();
		m1.display1();
		hello h1=new hello();
		h1.display();
		
	}

}

