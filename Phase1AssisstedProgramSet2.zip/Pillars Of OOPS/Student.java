package Assisted_Practice_2;

public class Student {
	
	int id;
	String name;
	String gender;
	String section;
	int age;
	
	Student(int id, String name, String gender, String section, int age)
	{
		this.id=id;
		this.name=name;
		this.gender=gender;
		this.section=section;
		this.age=age;
		
	}
	

	public int getId() {
		return id;
	}




	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getSection() {
		return section;
	}





	public void setSection(String section) {
		this.section = section;
	}





	public int getAge() {
		return age;
	}





	public void setAge(int age) {
		this.age = age;
	}
	
	void display()
	{
		System.out.println("\nStudent ID: "+this.getId());
		System.out.println("\nStudent name: "+this.getName());
		System.out.println("\nStudent Gender: "+this.getGender());
		System.out.println("\nStudent Section: "+this.getSection());
		System.out.println("\nStudent Age: "+this.getAge());
	}





	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s=new Student(101,"Harry","M","B",20);
		s.display();
		

	}

}
