package Assisted_Practice_2;

public class Encapsulation {
	
	private int stud_id;
	private String stud_name;
	private int stud_age;
	
	

	public int getStud_id() {
		return stud_id;
	}



	public void setStud_id(int stud_id) {
		this.stud_id = stud_id;
	}



	public String getStud_name() {
		return stud_name;
	}



	public void setStud_name(String stud_name) {
		this.stud_name = stud_name;
	}



	public int getStud_age() {
		return stud_age;
	}



	public void setStud_age(int stud_age) {
		this.stud_age = stud_age;
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Encapsulation e=new Encapsulation();
		e.setStud_id(101);
		e.setStud_name("Harry");
		e.setStud_age(21);
		
		System.out.println("\nStudent ID: "+e.getStud_id());
		System.out.println("\nStudent Name: "+e.getStud_name());
		System.out.println("\nStudent Age: "+e.getStud_age());

	}

}
