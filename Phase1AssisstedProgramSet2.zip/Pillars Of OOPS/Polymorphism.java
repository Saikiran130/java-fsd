package Assisted_Practice_2;

class employee{
	int emp_id=101;
	String emp_name="Vicky";
	void display()
	{
		System.out.println("\nEmployee ID: "+emp_id);
		System.out.println("\nEmployee Name: "+emp_name);
	}
	void salary()
	{
		System.out.println("\nSalary of Permanent,Temporary and Contract Employee are listed below");
	}
	
}

class per_employee extends employee{
	void salary(){
		int sal=30000;
		System.out.println("\nPermananent Employee: "+sal);
	}
}

class temp_employee extends per_employee{
	void salary()
	{
		int sal=15000;
		System.out.println("\nTemporary Employee: "+sal);
	}
}

class contract_employee extends per_employee{
	void salary()
	{
		int sal=12000;
		System.out.println("\nContract Employee: "+sal);
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employee p=new employee();
		p.display();
		p.salary();
		
		
		p=new per_employee();
		p.salary();
		
		p=new temp_employee();
		p.salary();
		
		p=new contract_employee();
		p.salary();
		
	}

}
