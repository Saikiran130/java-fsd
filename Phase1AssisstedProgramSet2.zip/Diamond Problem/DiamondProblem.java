package Assisted_Practice_2;

interface first{
	default void Cir_area(int a, int b)
	{
		System.out.println("\nArea Of Circle: "+(0.5*a*b));
	}
}

interface second{
	default void Rec_area(int a, int b)
	{
		System.out.println("\nArea Of Rectangle: "+(a*b));
	}
}

public class DiamondProblem implements first,second {
	
	public void display()
	{
		first.super.Cir_area(10, 5);
		second.super.Rec_area(5, 7);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DiamondProblem d1=new DiamondProblem();
		d1.display();

	}

}
