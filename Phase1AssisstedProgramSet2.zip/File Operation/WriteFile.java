package File_Operations;

import java.io.FileWriter;
import java.util.Scanner;

public class WriteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the Content to write in a file");
		String str=s.nextLine();
		try{
		FileWriter fout=new FileWriter("D:\\FileHandling\\hello.txt");
		
		fout.write(str);
		System.out.println("\nContents are Written");
		fout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
