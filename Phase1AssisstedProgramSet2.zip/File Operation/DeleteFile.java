package File_Operations;

import java.io.File;

public class DeleteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
	
		File f=new File("D:\\FileHandling\\hello.txt");
		boolean b=f.delete();
		if(b)
		{
			System.out.println("\nFile Name: "+f.getName()+" "+"is Deleted");
		}
		else{
			System.out.println("\nFile Name: "+f.getName()+" "+"is not Deleted");
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	}

}
