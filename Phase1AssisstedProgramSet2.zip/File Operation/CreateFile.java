package File_Operations;

import java.io.File;

public class CreateFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			File f=new File("D:\\FileHandling\\hello.txt");
		
			if(f.createNewFile())
			{
				System.out.println("\nFile Name: "+f.getName()+" "+"is created");
			}
			else{
				System.out.println("\nFile Already Exist");
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}

	}

}
