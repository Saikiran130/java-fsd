package File_Operations;

import java.io.FileReader;

public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char arr[]=new char[50];
		try{
		FileReader fin=new FileReader("D:\\FileHandling\\hello.txt");
		
		fin.read(arr);
		System.out.println("\nContents in the File");
		System.out.println(arr);
		fin.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
