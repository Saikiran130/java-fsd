package Threadprgm;

public class Threadmethod implements Runnable {
	int total=10;
	public void run()
	{
		
		total+=10;
		try{
			Thread.sleep(1000);
		}
		catch(InterruptedException i1)
		{
			i1.printStackTrace();
		}
		
		System.out.println(Thread.currentThread().getName()+" is running after sleep");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Threadmethod t1=new Threadmethod();
		Thread t=new Thread(t1,"My Thread");
	    Thread t2=new Thread(t1,"My second Thread");
		t.start();
		t.setPriority(7);
		String str=t.getName();
		System.out.println(str);
		
		t2.start();
		t2.setPriority(9);
		String str1=t2.getName();
		System.out.println(str1);
		

	}

}
