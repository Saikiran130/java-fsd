package ExceptionHandling;

import java.util.Scanner;

class ageexception extends Exception{
	ageexception(String msg)
	{
		super(msg);
	}
}
public class CustomException {
	
	void cal_age(int val)throws ageexception
	{
		if(val<18)
		{
			throw new ageexception("\nYour are Minor");
		}
		else if(val>=18)
		{
			throw new ageexception("\nYou are Major");
		}
		else if(val>=60)
		{
			throw new ageexception("\nYou are Senior Citizen");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomException c=new CustomException();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter your Age");
		int n=s.nextInt();
		try{
			c.cal_age(n);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}

}
