import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
  homefunc()
  {
    this.router.navigate(['Home']);
  }

  constructor(private router : Router) { }

  ngOnInit() {
  }

}
