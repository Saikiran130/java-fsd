package Practice_Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Prog {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
	System.setProperty("webdriver.chrome.driver", "D:\\Chrome driver\\chromedriver.exe");
		
	WebDriver driver = new ChromeDriver();
		
	driver.get("https://www.facebook.com/");
	driver.manage().window().maximize();
	Thread.sleep(2000);
	
	 driver.findElement(By.cssSelector("#email")).sendKeys("saikiran");
	 Thread.sleep(4000);
	 driver.findElement(By.cssSelector("#pass")).sendKeys("123456");
	 Thread.sleep(4000);
	    //driver.findElement(By.cssSelector("#u_0_9_Oi")).click();
	    //driver.findElement(By.className("login")).click();
	 driver.findElement(By.xpath("//button[@class='_42ft _4jy0 _6lth _4jy6 _4jy1 selected _51sy']")).click();
	    
	 Thread.sleep(4000);
	 driver.quit();

	}

}
