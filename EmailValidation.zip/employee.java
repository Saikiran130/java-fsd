package Emailvalidation;

import java.util.ArrayList;

public class employee {
	
	void Search_email(ArrayList<String> al,String email)
	{
		if(al.contains(email))
		{
			System.out.println("\nSearched Email Id IS Found");
		}
		else{
			System.out.println("\nSearched Email Id is Not Found in the List");
		}
	}

	
}
