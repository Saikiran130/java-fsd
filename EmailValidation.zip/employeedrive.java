package Emailvalidation;

import java.util.ArrayList;
import java.util.Scanner;

public class employeedrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employee e=new employee();
		ArrayList<String> al=new ArrayList<>();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the Size Of a List ");
		int n=s.nextInt();
		System.out.println("\nEnter "+n+" "+"Email Id's of an Employees");
		while(n>0)
		{
			String str=s.next();
			al.add(str);
			n--;
		}
		System.out.println("\nEnter the Email ID To Search");
		String search=s.next();
		
		e.Search_email(al, search);
		
		

	}

}
