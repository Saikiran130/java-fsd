package FileHandling;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;

public class AppendFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		DataInputStream dis=new DataInputStream(System.in);
		FileOutputStream fout=new FileOutputStream("D:\\FileHandling\\Test.txt",true);
		BufferedOutputStream buf=new BufferedOutputStream(fout,1024);
		
		System.out.println("\nEnter * at Last of sentence to end");
		char ch;
		
		while((ch=(char)dis.read())!='*')
		{
			buf.write(ch);
		}
		buf.close();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
