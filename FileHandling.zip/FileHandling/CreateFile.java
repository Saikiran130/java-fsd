package FileHandling;

import java.io.File;

public class CreateFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		File f=new File("D:\\FileHandling\\Test.txt");
		
		if(f.createNewFile())
		{
			System.out.println("\nFile Name: "+f.getName()+" "+"is Created");
		}
		else{
			System.out.println("\nFile Name: "+f.getName()+" "+"File Already Exist");
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	}

}
