package FileHandling;

import java.io.FileWriter;
import java.util.Scanner;

public class WriteFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		String str="";
		System.out.println("\nEnter the content to write in a file");
		str=s.nextLine();
		try{
		FileWriter fout=new FileWriter("D:\\FileHandling\\Test.txt");
		fout.write(str);
		System.out.println("\nContent is Written");
		fout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
