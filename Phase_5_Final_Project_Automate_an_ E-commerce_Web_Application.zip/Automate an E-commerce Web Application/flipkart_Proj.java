package Practice.Project;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class flipkart_Proj {
	
	@Test
	public void setup() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
	    
	  //capture time before page load
	     long s = System.currentTimeMillis();
	    //Opening Browser
	    driver.get("https://www.flipkart.com/");
	    long e = System.currentTimeMillis();
	     //compute time
	     long r = e-s;
	     System.out.println("Page load time in milliseconds: "+ r);
	    
	    driver.manage().window().maximize();
	    System.out.println("===========================");
	    System.out.println("Website Open!!");
	    
	    driver.findElement(By.xpath("//input[@class='_3704LK']")).sendKeys("iphone 13");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.xpath("//button[@class='L0Z3Pu']")).click();
	    Thread.sleep(4000);
	    System.out.println("===========================");
	    System.out.println("Mobile selected");
	    
	    driver.findElement(By.partialLinkText("APPLE iPhone 13 (Starlight, 128 GB)")).click();
	    Thread.sleep(4000);
	    
	    Set<String> Handles = driver.getWindowHandles();
	    
	    for(String actual: Handles)
	    {
	    	driver.switchTo().window(actual);
	    }
	    
	    String execScript = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Boolean test = (Boolean) (js.executeScript(execScript));
		System.out.println("===========================");
		if (test == true) {
			System.out.println("Scrollbar is present.");
		} else if (test == false){
			System.out.println("Scrollbar is not present.");
		}
	  
	    Thread.sleep(2000);
	    
	    driver.navigate().refresh();
	    Thread.sleep(2000);
	    
	    System.out.println("===========================");
	    System.out.println("Refresh Done");
	    
	    driver.manage().timeouts().implicitlyWait(8, TimeUnit.SECONDS);
	    Thread.sleep(2000);
	    System.out.println("===========================");
	    System.out.println("Wait Check");
	    
	    
	    js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	    Thread.sleep(2000);
	    System.out.println("===========================");
	    System.out.println("Page scrolled to bottom of the page");
	    
	    js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
	    Thread.sleep(2000);
	    System.out.println("===========================");
	    System.out.println("Page scrolled to top of the page");
	    
	    driver.quit();
	    
	}

}
