package Movie_ticket_booking;


public class Main_booking {

public static void main(String[] args) {
	
	
		Ticket_booking t1=new Ticket_booking();
		System.out.println("\n**************************************");
		System.out.println("\nWelcome to Movie Ticket Booking System");
		System.out.println("\n**************************************");
		t1.showoption();
		
		
	}

}
