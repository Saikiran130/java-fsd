package Movie_ticket_booking;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

class Ticket_booking {

	String s1;
	String s2;
	String s3;
	String selected_show_time=" ";
    int no_of_persons;
    String seat;
    char selected_row;
    String username;
    String password;
    String selected_movie;
    int price=200;
    int total;
    Scanner s=new Scanner(System.in);
    HashMap<String,String> user=new HashMap<>();
    ArrayList<String> al=new ArrayList<>();
    ArrayList movies=new ArrayList<>();
    ArrayList booked=new ArrayList<>();
    ArrayList ShowTime=new ArrayList();
    LinkedList A_row=new LinkedList();
    LinkedList B_row=new LinkedList();
    LinkedList C_row=new LinkedList();
    LinkedList D_row=new LinkedList();
    LinkedList E_row=new LinkedList();
    LinkedList F_row=new LinkedList();
    

    
    Ticket_booking()
    
    {
    	
    	user.put("Pavan", "123");
    	user.put("Pradeep", "79");
    	user.put("Rizwan", "96");
    	user.put("Sethu", "111");
    	user.put("Jonas", "Jonas12");
    	movies.add("Thor Love & Thunder");
    	movies.add("Doctor Strange");
    	movies.add("Loki");
    	ShowTime.add("9am to 12pm");
    	ShowTime.add("1pm to 4pm");
    	ShowTime.add("6pm to 9pm");
    	
    }
	
    
    void register(String s1, String s2)
    {
    	user.put(s1, s2);
    	System.out.println("\nRegistration successful Now you can login to proceed");
    	
    }
    
    void login(String username, String password)
    {
    	if(user.containsKey(username) && user.containsValue(password))
    	{
    		System.out.println("\nLogin Successful");
    	}
    	else{
    		System.out.println("\nLogin not successfull");
    		System.out.println("\nTry to login with correct username & password");
    		reg_login_user();
    	}
    }
    
    void reg_login_user()
    {
    	Scanner s=new Scanner(System.in);
    	System.out.println("\nChoose Register if u are new user");
		System.out.println("\n1.Register  \n2.Login");
		int x=s.nextInt();
		switch(x)
		{
		case 1:
			System.out.println("\nSet your username");
			username=s.next();
			System.out.println("\nSet your Password");
			password=s.next();
			register(username,password);
			reg_login_user();
			break;
		
		case 2:
			System.out.println("\nYou have choosed Login ");
			System.out.println("\nEnter your username");
			username=s.next();
			System.out.println("\nEnter your Password");
			password=s.next();
			login(username,password);
			showmovie();
			showtime();
			select_no_of_persons();
			select_row();
			break;
		
	
		default:
			System.out.println("\nInvalid Option");
			break;
		}
		
    	
    }
    
	void showoption(){
		System.out.println("\nAre you a user or admin");
		System.out.println("\n1.Admin 2.User");
		Scanner s=new Scanner(System.in);
		Scanner sc=new Scanner(System.in);
		System.out.println("\nEnter your Choice");
		int choice=s.nextInt();
		switch(choice)
		{
		case 1:
		{
			System.out.println("\n1.Add User  \n2.Remove User  \n3.Print User  \n4.View Last Booking \n5.Add Movie  \n6.Remove Movie ");
			System.out.println("\nEnter Your Choice");
			int opt=s.nextInt();
			if(opt==1){
				System.out.println("\nEnter the username");
				String username=s.next();
				System.out.println("\nEnter the Password");
				String password=s.next();
				user.put(username, password);
				System.out.println("\nUsername: "+username+" is Added");
				showoption();
			}
			else if(opt==2)
			{
				System.out.println(user);
				System.out.println("\nEnter the username you want to remove");
				String username=s.next();
				user.remove(username);
				System.out.println("\nUsername: "+username+" is Removed!!");
				showoption();
			}
			else if(opt==3)
			{
				System.out.println("\nRegistered Users in the System");
				System.out.println(user);
				showoption();
			}
			else if(opt==4)
			{
				if(booked.isEmpty())
				{
					System.out.println("\nNo Bookings");
					showoption();
				}
				else{
					System.out.println("\nLast Booking");
					System.out.println(booked);
					showoption();
				}
			}
			else if(opt==5)
			{
				System.out.println("\nEnter the movie name to add");
				String new_movie=sc.nextLine();
				movies.add(new_movie);
				System.out.println("\nMovie name: "+new_movie+" is added into list");
				showoption();
			}
			else if(opt==6)
			{
				System.out.println("\nEnter the Movie name you want to remove");
				String rem_movie=sc.nextLine();
				if(movies.contains(rem_movie))
				{
					movies.remove(rem_movie);
					System.out.println("\nMovie Name: "+rem_movie+" is Removed!!");
					showoption();
				}
				else{
					System.out.println("\nEntered movie is not present!! ");
					showoption();
					
				}
			}
			
			else{
				System.out.println("\nPlease choose correct option");
				showoption();
			}
			break;
		}
		case 2:
		{
			reg_login_user();
			break;
		}
		
		default:
			System.out.println("\nInvalid Choice");
		}
	}
	
	void showmovie()
	{
		Scanner s=new Scanner(System.in);

		
		System.out.println("\nSelect the movie");
		System.out.println();
		
		for(int i=0;i<movies.size();i++)
		{
			System.out.println("--> "+movies.get(i));
		}
		System.out.println("\nEnter the movie name");
		String mov_name=s.nextLine();
		if(movies.contains(mov_name))
		{
			selected_movie=mov_name;
			System.out.println("\nSelected movie: "+selected_movie);
			
		}
		else{
			System.out.println("\nplease select movie from the above list");
			showmovie();
		}
		
		
	}

	void showtime()
	{
		
		Scanner s=new Scanner(System.in);
		System.out.println("\nSelect the Show Time");
		String s1="9am to 12pm";
		String s2="1pm to 4pm";
		String s3="6pm to 9pm";
		System.out.println("\n1.9am to 12pm   \n2.1pm to 4pm   \n3.6pm to 9pm");
		System.out.println("\nEnter Your Choice: ");
		int ch=s.nextInt();
		switch(ch)
		{
		case 1:
			selected_show_time=s1;
			System.out.println("\nSelected Show Time: "+selected_show_time);
			break;
		
		case 2:
			selected_show_time=s2;
			System.out.println("\nSelected Show Time: "+selected_show_time);
			break;
			
		case 3:
			selected_show_time=s3;
			System.out.println("\nSelected Show Time: "+selected_show_time);
			break;
		
		default:
			System.out.println("\nInvalid Choice");
			break;
		
		}
		
	}
	
	void select_no_of_persons()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the no of persons you want to book");
		no_of_persons=s.nextInt();
		System.out.println("\nYou have Selected tickets for a movie name: "+selected_movie );
		System.out.println("\nSelected show time @ "+selected_show_time);
		System.out.println("\nNumber of Persons You have Selected: "+no_of_persons);
	}
	
	void select_row()
	{
		Scanner s=new Scanner(System.in);
		System.out.println("\nSelect the row (A-F): ");
		char ch=s.next().charAt(0);
		if(ch>='A' && ch<='F')
		{
		switch(ch)
		{
		case 'A':
		{
			selected_row='A';
			System.out.println("\nYou have Choosed A Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(A_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			break;
		}
		case 'B':
		{
			selected_row='B';
			System.out.println("\nYou have Choosed B Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(B_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			break;
		}
		case 'C':
		{
			selected_row='C';
			System.out.println("\nYou have Choosed C Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(C_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			break;
		}
		case 'D':
		{
			selected_row='D';
			System.out.println("\nYou have Choosed D Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(D_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			
			break;
		}
		case 'E':
		{
			selected_row='E';
			System.out.println("\nYou have Choosed E Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(E_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			break;
		}
		case 'F':
		{
			selected_row='F';
			System.out.println("\nYou have Choosed F Row");
			System.out.println("\nSelect the seats (1-10)");
			seat=s.next();
			if(Integer.valueOf(seat)>=1&&Integer.valueOf(seat)<=10)
			{
			seat=selected_row+seat;
			select_seat(F_row,seat,selected_row);
			}
			else{
				System.out.println("\nSeat value ranges from 1-10 select only from these");
			}
			break;
		}
		default:
			System.out.println("\nInvalid choice");
			break;
		}
		}
		else{
			System.out.println("\nRow ranges from (A-F) ");
			System.out.println("\nPlease do Select from the above range");
			select_row();
		}
		
	}
	
	void select_seat(LinkedList l1, String s1,char row)
	{
		if(l1.contains(s1))
		{
			System.out.println("\nSeat is already booked");
			System.out.println("\nTry with different seat number");
			select_row();
				
			
		}
		else{
			al.add(s1);
			l1.add(s1);
			System.out.println("\nYour selected row & seat number "+s1);
			System.out.println("\nDo you want to book another seat (y/n)?: ");
			char c=s.next().charAt(0);
			if(c=='y')
			{
					select_row();
			}
			else{
				payment(no_of_persons,price,l1);
				
			}
		}
	}
	
	void payment(int no_user,int p,LinkedList obj)
	{
		Scanner sc=new Scanner(System.in);
		total=no_user*p;
		System.out.println("\nSeats Selected: "+obj);
		System.out.println("\nTotal amount for the booked tickets: "+total);
		System.out.println("\nType (y/n) to confirm booking");
		char cnfrm=sc.next().charAt(0);
		if(cnfrm=='y')
		{
			display();
		}
		else{
			System.out.println("\nLast Booking Cancelled");
			cancel(al,obj,seat);
			
		}
	}
	
	void display()
	{
		System.out.println("******************BOOKING CONFIRMED***********");
		System.out.println("\nHi "+username+" Your Booking is Confirmed :) :)");
		double bookingid=Math.random();
		String status="Completed";
		System.out.println("\nBooking ID: "+bookingid);
		System.out.println("\nUsername: "+username);
		System.out.println("\nMovie name: "+selected_movie);
		System.out.println("\nShowTime: "+selected_show_time);
		//System.out.println("\nSelected Row: "+selected_row);
		System.out.println("\nSelected Seats: "+al);
		System.out.println("\nNo of Persons: "+no_of_persons);
		System.out.println("\nTotal Amount: "+total);
		System.out.println("\nPayment Status: "+status);
		System.out.println("\n*********************************************");
		booked.add(bookingid);
		booked.add(selected_movie);
		booked.add(selected_show_time);
		booked.add(al);
		booked.add(no_of_persons);
		booked.add(total);
		booked.add(status);
		
		System.out.println("\nDo you want to book again (y/n)?: ");
		char ch=s.next().charAt(0);
		if(ch=='y')
		{
			showoption();
		}
		else if(ch=='n'){
			System.out.println("\nThank You for Using our System");
		}
		else{
			System.out.println("\nInvalid Choice");
		}
	}
	
	void cancel(ArrayList<String> arraylist,LinkedList obj1,String s3)
	{
		System.out.println("\nSorry "+username+" :( :(");
		System.out.println("\nYour Last Booking is Cancelled");
		arraylist.remove(seat);
		obj1.remove(seat);
		System.out.println("\nIf you want to start booking again (y/n)?:  ");
		char ch=s.next().charAt(0);
		if(ch=='y')
		{
			showoption();
		}
		else if(ch=='n'){
			System.out.println("\nThank You for Using our System ");
		}
		else{
			System.out.println("\nInvalid Choice");
		}
	}


}
		
	
	


