package Practice.Project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class login_cart {
	
	@Test
	public void before () throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Chrome driver\\chromedriver.exe");
		// Step 1: load the chrome driver
	    //System.setProperty("webdriver.chrome.driver", "C:\\Users\\Virendra\\Desktop\\Simplilearn\\All Phases\\Phase-5\\Selenium Material\\chromedriver.exe");
	    WebDriver driver = new ChromeDriver();
	    
	    driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fs%3Fk%3DKingston%2BDataTraveler%2BSwivl%2B32GB%2BUSB%2B3.0%2BPen%2BDrive%2B%2528DTSWIVL%252F32GBIN%252C%2BBlack%2529%26i%3Dcomputers%26crid%3D4WRSUEE07OL2%26sprefix%3Dkingston%2Bdatatraveler%2Bswivl%2B32gb%2Busb%2B3.0%2Bpen%2Bdrive%2Bdtswivl%252F32gbin%252C%2Bblack%2B%252Ccomputers%252C362%26ref%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
	    driver.manage().window().maximize();
	    Thread.sleep(4000);
	    
	    driver.findElement(By.xpath("//input[@class='a-input-text a-span12 auth-autofocus auth-required-field']")).sendKeys("Sai@gmail.com");
	    Thread.sleep(4000);
	    
	    driver.findElement(By.xpath("//input[@class='a-button-input']")).click();
	    Thread.sleep(4000);
	    
	    driver.findElement(By.xpath("//input[@class='a-input-text a-span12 auth-autofocus auth-required-field']")).sendKeys("123456789");
	    Thread.sleep(4000);
	    
	    driver.findElement(By.xpath("//input[@class='a-button-input']")).click();
	    Thread.sleep(4000);
	    
	    driver.get("https://www.amazon.in/");
	    driver.manage().window().maximize();
	    Thread.sleep(4000);
	    
	    driver.findElement(By.id("twotabsearchtextbox")).sendKeys("pendrives");
	    Thread.sleep(4000);
	    
	    driver.findElement(By.id("nav-search-submit-button")).click();
	    Thread.sleep(6000);
	    
	    driver.findElement(By.linkText("Kingston")).click();
	    Thread.sleep(6000);
	    
	    driver.findElement(By.partialLinkText("Kingston DataTraveler Swivl 32GB USB 3.0 Pen Drive (DTSWIVL/32GBIN, Black)")).click();
	    Thread.sleep(6000);
	    
	    //driver.findElement(By.cssSelector("#addToCart >div>div>div>div>div:nth-child(3)>div>div:nth-child(33)>div>span>span>span>input")).click();
	    //Thread.sleep(4000);
	    
	    driver.close();
	}
	
	
	

}
