package com.example.springaws;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class maincontroller {

		@ResponseBody
		@RequestMapping("/")
		public String  display()
		{
			return "My first Project is successfully uploaded to AWS";
		}

	

}
