import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';

import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RouteGuardService } from './service/route-guard.service';

const routes: Routes = [
  { path:'',component:LoginComponent},
  { path:'login',component:LoginComponent},
  { path:'Employeedashboard/:name',component:EmployeeDashboardComponent,canActivate: [RouteGuardService]},
  { path:'logout',component:LogoutComponent, canActivate: [RouteGuardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
