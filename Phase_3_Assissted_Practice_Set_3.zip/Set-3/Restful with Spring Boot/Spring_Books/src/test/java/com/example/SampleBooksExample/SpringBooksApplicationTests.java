package com.example.SampleBooksExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
