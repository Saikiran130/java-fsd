package com.example.SampleBooksExample;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookController {
	
	@Autowired
	private BookService service;
	
	@PostMapping("/insertbook")
	public Book insertbook(@RequestBody Book b)
	{
		return service.insertBook(b);
	}
	
	@PostMapping("/insertallbook")
	public List<Book> insertallbook(@RequestBody List<Book> b)
	{
		return service.inserallBook(b);
	}
	
	@GetMapping("/getBooks")
	public List<Book> getAllBook()
	{
		return service.getAllbook();
	}
	
	@GetMapping("/getBooks/{id}")
	public Book getBookbyid(@PathVariable int id)
	{
		return service.getBookById(id);
	}
	
	@GetMapping("/getBookspid/{pid}")
	public List<Book> getBookByPid(@PathVariable int pid)
	{
		return service.getBookByPublisherid(pid);
	}
	
	@GetMapping("/delete/{id}")
	public String deletebook(@PathVariable int id)
	{
		return service.delete(id);
	}
	
	@GetMapping("/deleteall")
	public String deleteallbook()
	{
		return service.deleteall();
	}
	
	@PutMapping("/update/{id}")
	public Book updateUser(@RequestBody Book b1) {
	   return  service.update(b1);
	   
	}
	
	
	

}
