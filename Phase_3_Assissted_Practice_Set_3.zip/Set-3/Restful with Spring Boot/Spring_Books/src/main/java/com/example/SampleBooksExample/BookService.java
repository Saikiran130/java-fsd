package com.example.SampleBooksExample;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
	
	@Autowired
	private BookRepo rep;
	
	Book b1=new Book();
	
	
	public Book insertBook(Book b)
	{
		return rep.save(b);
	}
	
	public List<Book> inserallBook(List<Book> b)
	{
		return rep.saveAll(b);
	}
	
	public List<Book> getAllbook()
	{
		return rep.findAll();
	}
	
	public Book getBookById(int id)
	{
		return rep.findById(id).orElse(null);
	}
	
	public List<Book> getBookByPublisherid(int pid)
	{
		return rep.findBypublishedyear(pid);
	}
	
	public String delete(int id) {
		 rep.deleteById(id);
		 return "deleted the id "+id;
	}
	
	public String deleteall()
	{
		rep.deleteAll();
		return "All datas are deleted";
	}
	
	public Book update(Book b1)
	{
		return rep.save(b1);
		
	}
	
	

	
	
	
	

}
