package com.example.SampleBooksExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBooksApplication.class, args);
	}

}
