package ArithemeticCalculator;

import java.util.Scanner;

public class Calculatordrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice;
		Scanner s=new Scanner(System.in);
		Calculator c=new Calculator();
		while(true){
		System.out.println("\n1.Addition  \n2.Subraction  \n3.Multiplication  \n4.Division  \n5.Exit");
		System.out.println("\nEnter your choice: ");
		choice=s.nextInt();
		if(choice==1){
			System.out.println("\nEnter the First Number");
			double x=s.nextDouble();
			System.out.println("\nEnter the Next Number");
			double y=s.nextDouble();
            int add=(int) c.add(x,y);//TypeCast from double to int
            System.out.println("\nAddition Of Two Numbers"+" "+x+" "+"and"+" "+y+" "+"are"+" "+add);
            
            
		}
            
		else if(choice==2){
			System.out.println("\nEnter the First Number");
			double x=s.nextDouble();
			System.out.println("\nEnter the Next Number");
			double y=s.nextDouble();
            int sub=(int) c.sub(x,y);//TypeCast from double to int
            System.out.println("\nSubraction Of Two Numbers"+" "+x+" "+"and"+" "+y+" "+"are"+" "+sub);
            
        }
            
        else if(choice==3){
        	System.out.println("\nEnter the First Number");
    		double x=s.nextDouble();
    		System.out.println("\nEnter the Next Number");
    		double y=s.nextDouble();
            int multiply=(int)c.multiply(x,y);//TypeCast from double to int
            System.out.println("\nMultiplication Of Two Numbers"+" "+x+"and "+y+" "+"are"+" "+multiply);
            
           
        }
            
        else if(choice==4){
        	System.out.println("\nEnter the First Number");
    		double x=s.nextDouble();
    		System.out.println("\nEnter the Next Number");
    		double y=s.nextDouble();
    		//using try & Catch block to provide Divide by Zero Exception
            try{
                double temp = x/y;
                if(temp == Double.POSITIVE_INFINITY || temp == Double.NEGATIVE_INFINITY){
                    throw new ArithmeticException();
                }else{
                    int divide=(int)c.divide(x,y);//TypeCast from double to int
                    System.out.println("\nDivision Of Two Numbers"+" "+x+" "+y+" "+"are"+" "+divide);
                }
            }catch(ArithmeticException e){
                System.out.println("Divide by zero exception!");
            }
            
        }
		
           
            
        else if(choice==5){
        	System.out.println("\nYou Choose to Exit");
            break;
          }
		
        else{
        	System.out.println("\nInvalid Choice");
			
	}
	}
	}

	}


