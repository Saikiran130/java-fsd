package ArithemeticCalculator;


public class Calculator {

	
	public double add(double a, double b)
	{
		double res=a+b;
		return res;
	}
	
	protected double sub(double a, double b)
	{
		double res=a-b;
		return res;
	}
	
	double multiply(double a, double b)
	{
		double res=a*b;
		return res;
	}
	
	static double divide(double a, double b)
	{
		double res=a/b;
		return res;
	}
	

	
}


