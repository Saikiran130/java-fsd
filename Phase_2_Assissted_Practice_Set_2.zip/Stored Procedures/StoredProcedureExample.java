package sample.jdbc.program;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class StoredProcedureExample {
	
	static String url = "jdbc:mysql://localhost:3306/db_world";
    static String user = "root";
    static String password = "root";
    static String sql = "{call PRODUCT_PROC(?,?,?)}";
    
	private static Connection con;
	
   public static void main(String[] args) {
      
      try {
    	  
    	  //STEP 2: Register JDBC driver
	      try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	      //STEP 3: Open a connection
	      System.out.println("Connecting to database...");
	      con = DriverManager.getConnection(url, user, password);
	      
	      CallableStatement stmt=con.prepareCall(sql);
         
         //Set IN parameter
         stmt.setInt(1, 2);
         
         stmt.registerOutParameter(2, Types.VARCHAR);
         
         stmt.setDouble(3, 35.00);
         stmt.registerOutParameter(3, Types.DOUBLE);
       
         //Execute stored procedure
         stmt.execute();
         System.out.println("\nRecord Sucessfully Updated");
         
         // Get Out and InOut parameters
   
         
      } catch (SQLException e) {
         e.printStackTrace();
         e.getErrorCode();
      }
   }
}
