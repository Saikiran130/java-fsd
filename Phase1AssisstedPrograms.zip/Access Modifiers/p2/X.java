package p2;



public class X {

	private int a1=40;
	long l3=132324;
	protected float g=67.8f;
	public char ch='S';
	
	
}

