package Demoprograms;

public class innerclassprgm {
	
	class inner{
		public int add(int a, int b)
		{
			return a+b;
		}
		
		public int sub(int a, int b)
		{
			return a-b;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		innerclassprgm out=new innerclassprgm();
		innerclassprgm.inner in=out.new inner();
		System.out.println("\nInner Class Program");
		System.out.println("\n=====================");
		System.out.println("\nAddition of Two Numbers"+" "+in.add(40, 20));//accessing inner class method add
		System.out.println("\nSubraction of Two Numbers"+" "+in.sub(80, 23));//accessing inner class method sub

	}

}
