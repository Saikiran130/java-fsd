package Demoprograms;

import java.util.HashMap;
import java.util.Map;

public class Hashmapprgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> map=new HashMap<>();
		map.put(101, "Kennady");
		map.put(79, "Harry");
		map.put(80, "skeleton");
		map.put(88, "Joker");
		
		System.out.println("\nMap Key and Map Values");
		for(Map.Entry m:map.entrySet())
		{
			System.out.println("\n"+m.getKey()+" "+m.getValue());
		}
		
		map.remove(80);
		System.out.println("\nUpdated Map contents after removal"+" "+map);
		
		map.remove(88);
		System.out.println("\nUpdated Map contents after removal"+" "+map);
		
		map.replace(101, "Batman");
		System.out.println("\nAfter Replacing Map Contents"+" "+map);
		

	}

}
