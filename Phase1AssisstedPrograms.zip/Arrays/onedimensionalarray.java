package Arrays;

import java.util.Scanner;

public class onedimensionalarray {
	
	public int min(int arr[])
	{
		int min=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]<min)
			{
				min=arr[i];
			}
		}
		return min;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		onedimensionalarray o1=new onedimensionalarray();
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of the array");
		n=s.nextInt();
		int arr[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		
		int value=o1.min(arr);
		System.out.println("\nMinimum value in this array"+" "+value);
		

	}

}
