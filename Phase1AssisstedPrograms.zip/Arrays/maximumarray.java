package Demoprograms;

import java.util.Scanner;

public class maximumarray {
	void findmax(int arr[])
	{
		int max=arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
		}
		System.out.println("\nMaximum element in this array is: "+max);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		maximumarray m1=new maximumarray();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of an array");
		int n=s.nextInt();
		
		int arr[]=new int[n];
		System.out.println("\nEnter the array Elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		m1.findmax(arr);
		
		
		

	}

}
