package Demoprograms;

import java.util.ArrayList;
import java.util.Scanner;

public class arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the Size of List");
		int n=s.nextInt();
		ArrayList<Integer> al=new ArrayList<>(n);
		System.out.println("\nEnter "+n+" "+"no of elements");
		while(n>0)
		{
			int x=s.nextInt();
			al.add(x);
			n--;
		}
		
		System.out.println("\nEnter the number you want to search");
		int z=s.nextInt();
		
			if(al.contains(z))
			{
				System.out.println("\nElement is present in List");
			}
			else{
				System.out.println("\nElement is not present ");
			}
		
		

	}

}
