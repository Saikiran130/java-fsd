package Demoprograms;

import java.util.HashSet;
import java.util.Set;
import java.util.*;

public class hashsetprgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer> set=new HashSet<>();
		
		set.add(21);
		set.add(43);
		set.add(45);
		set.add(32);
		set.add(54);
		
		System.out.println("\nElements in the set are"+" "+set);
		
		Set<Integer> set2=new HashSet<>();
		set2.add(32);
		set2.add(54);
		
		System.out.println("\nChecking Set contains Set2 Elements: "+set.containsAll(set2));
		
		set2.clear();
		System.out.println("\nChecking if the set2 is empty or not?: "+set2.isEmpty());
		

	}

}
