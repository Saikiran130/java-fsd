package Demoprograms;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regexprgm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println(Pattern.matches(".i","vi"));
		System.out.println(Pattern.matches(".s", "harry"));
		System.out.println(Pattern.matches("..h", "john"));
		
		System.out.println(Pattern.matches("[elo]", "hello"));
		
		System.out.println("Enter regex pattern:");  
        Pattern pattern = Pattern.compile(s.nextLine());    
        System.out.println("Enter text:");  
        Matcher matcher = pattern.matcher(s.nextLine());    
        boolean found = false;    
        while (matcher.find()) {    
            System.out.println("I found the text "+matcher.group()+" starting at index "+    
             matcher.start()+" and ending at index "+matcher.end());    
            found = true;    
        }    
        if(!found){    
            System.out.println("No match found.");    
        }    

	}

}
