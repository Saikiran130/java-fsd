package Demoprograms;

public class stringfunctions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="string functions Program";
		String s2="string functions";
		
		System.out.println(s1.charAt(5));
		
		System.out.println(s1.codePointAt(11));
		
		System.out.println(s1.codePointBefore(17));
		
		System.out.println(s1.codePointCount(0, 6));
		
		System.out.println("\nString Comparison Function");
		
		System.out.println(s1.compareTo(s2));
		
		System.out.println(s1.compareToIgnoreCase(s2));
		
		System.out.println("\nString Concatenate Function");
		
		System.out.println(s1.concat(s2));
		
		System.out.println(s1.contains(s2));
		
		System.out.println(s2.contains(s1));
		
		System.out.println(s1.endsWith("gram"));
		
		System.out.println(s1.equals(s2));
		
		System.out.println(s1.equalsIgnoreCase(s2));
		
		System.out.println(s1.hashCode());
		
		System.out.println(s1.indexOf("functions"));
		
		String s3="random";
		System.out.println(s3.isEmpty());
		
		s3="sai kiran sai";
		System.out.println("\nLast Occurence Position");
		System.out.println(s3.lastIndexOf("sai"));
		
		System.out.println(s1.length());
		
		System.out.println(s3.replace("kiran", "holic"));
		System.out.println(s3);
		
		System.out.println(s1.startsWith("string"));
		
		String s4="welcome all";
		System.out.println(s1.toLowerCase());
		
		System.out.println(s1.toUpperCase());
		
		s4="       Welcome all    ";
		
		System.out.println(s4.trim());

	}

}
