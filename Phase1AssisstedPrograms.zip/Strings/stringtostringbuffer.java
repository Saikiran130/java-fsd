package Demoprograms;

public class stringtostringbuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="Hello";
		
		//converting string literal to stringbuffer
		StringBuffer sb=new StringBuffer();
		sb.append(str);
		
		//converting str2 string to stringbuffer
		String str2="Welcome To Ecllipse IDE";
		sb.append("  "+str2);
		
		sb.insert(6, "coder");//insert coder at position 6 in str
		
		System.out.println(sb);
		
		sb.reverse();
		System.out.println("\nAfter Reversing the String: "+" "+sb);

	}

}
