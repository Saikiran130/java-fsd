package programs;

public class samplemethod {
	
	public int rectangle(int l, int b)
	{
		return l*b;
	}

	public static void main(String[] args) {
		
		samplemethod s=new samplemethod();
		int res=s.rectangle(5, 5);
		
		System.out.println("\nArea of Rectangle is"+" "+res);

	}

}
