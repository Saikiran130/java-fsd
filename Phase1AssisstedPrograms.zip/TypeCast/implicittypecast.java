package programs;

public class implicittypecast {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1=456;
		long h2=(long) a1;
		
		char ch='e';
		int x1=(int)ch;
		
		float f1=3.45f;
		double d1=(double)f1;
		
		System.out.println("Actual int value"+" "+a1);
		System.out.println("\nAfter convert int to long"+" "+h2);
		
		
		System.out.println("\nActual Character Value "+ch);
		System.out.println("\nAfter convert char to int "+x1);
		
		System.out.println("\nActual Float Value "+f1);
		System.out.println("\nAfter Float char to double "+d1);
		

	}

}
