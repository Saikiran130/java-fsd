package CircularLinkedList;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList l1=new LinkedList();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of an array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the Array Elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		Node tem=null;
		for(int i=0;i<n;i++)
		{
			tem=new Node(arr[i]);
			l1.sortedInsert(tem);
		}
		System.out.println("\nAfter passing random array elements for sorting");
		l1.show();
		

	}

}
