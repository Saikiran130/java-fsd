package DatastructurePrograms;

import java.util.Scanner;

public class ArrayMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of m & n");
		int m=s.nextInt();
		int n=s.nextInt();
		int arr[][]=new int[m][n];
		int arr1[][]=new int[m][n];
		System.out.println("\nEnter the first array elements");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				arr[i][j]=s.nextInt();
			}
		}
		System.out.println("\nEnter the second array elements");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				arr1[i][j]=s.nextInt();
			}
		}
		int res[][]=new int[m][n];
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				res[i][j]=arr[i][j]*arr1[i][j];
			}
		}
		System.out.println("\nResultant array");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				System.out.print(res[i][j]+" ");
			}
			System.out.println();
		}
		

	}

}
