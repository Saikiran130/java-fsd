package DatastructurePrograms;

import java.util.Scanner;
import java.util.Stack;

public class Stackdemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Stackdemo s1=new Stackdemo();
		Stack<Integer> st=new Stack<>();
		st.push(10);
		st.push(11);
		st.push(12);
		st.push(13);
		st.push(14);
		st.push(15);
		
		System.out.println("\nElements in Stack:");
		System.out.println(st);
		System.out.println("\nEnter no of pop operations: ");
		int rem=s.nextInt();
		while(rem!=0)
		{
			st.pop();
			rem--;
		}
		System.out.println("\nElements in Stack After Performing Pop operation:");
		System.out.println(st);
		
		
	
		
	}

}
