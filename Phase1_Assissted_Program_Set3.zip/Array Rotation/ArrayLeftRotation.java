package DatastructurePrograms;

import java.util.Scanner;

public class ArrayLeftRotation {
	static void  Left_rotate(int arr[], int r)
	{
		for(int i=0;i<r;i++)
		{
			int first,j;
			first=arr[0];
			
			for( j=0;j<arr.length-1;j++)
			{
				arr[j]=arr[j+1];
			}
			arr[j]=first;
			
		}
		
	}
	
	static void print_array(int arr[], int n)
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayLeftRotation r1=new ArrayLeftRotation();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the Size of an array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the array elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		System.out.println("\nEnter how many times to rotate");
		int rot=s.nextInt();
		Left_rotate(arr,rot);
		System.out.println("\nArray Elements after Left Rotataion");
		print_array(arr,n);
		
	}

}
