package DatastructurePrograms;

import java.util.Scanner;

public class ArrayRightRotation {
	static void  right_rotate(int arr[], int r)
	{
		for(int i=0;i<r;i++)
		{
			int last;
			last=arr[arr.length-1];
			
			for(int j=arr.length-1;j>0;j--)
			{
				arr[j]=arr[j-1];
			}
			arr[0]=last;
			
		}
		
	}
	
	static void print_array(int arr[], int n)
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayRightRotation r1=new ArrayRightRotation();
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the Size of an array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the array elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		System.out.println("\nEnter how many times to rotate");
		int rot=s.nextInt();
		right_rotate(arr,rot);
		System.out.println("\nArray Elements after Right Rotataion");
		print_array(arr,n);
		
	}

}
