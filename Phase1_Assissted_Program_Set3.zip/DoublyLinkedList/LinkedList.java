package DoublyLinkedList;

public class LinkedList {
	Node head;
	
	void push(int new_data)
	{
		Node n=new Node();
		n.data=new_data;
		n.prev=null;
		
		n.next=head;
		
		if(head!=null)
		{
			head.prev=n;
		}
		head=n;
	}
	
	void reverse()
	{
		 Node temp=null;
	     Node current=head;
	  
	     while(current!=null) 
	     {
	    	temp=current.prev;
	    	current.prev=current.next;
	    	current.next=temp;
	    	current=current.prev;
	     }
	  
	     if (temp!=null) 
	     {
	        head=temp.prev;
	     }
	}
	
	void show()
	{
		Node temp=head;
		while(temp!=null)
		{
			System.out.println(temp.data);
			temp=temp.next;
		}
	}
	

}
