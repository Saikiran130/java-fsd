package DoublyLinkedList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList l1=new LinkedList();
		l1.push(23);
		l1.push(45);
		l1.push(67);
		l1.push(80);
		l1.push(36);
		System.out.println("\nTraverse in Formward Direction");
		l1.show();
		l1.reverse();
		System.out.println("\nTraverse in Backward Direction");
		l1.show();

	}

}
