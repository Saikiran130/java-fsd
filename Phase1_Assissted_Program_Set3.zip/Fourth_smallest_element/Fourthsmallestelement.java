package DatastructurePrograms;

import java.util.Arrays;
import java.util.Scanner;

public class Fourthsmallestelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int temp=0;
		System.out.println("\nEnter the Size of an array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the array elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]>arr[j])
				{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		System.out.println("\nFourth smallest element in array: "+arr[3]);

	}

}
