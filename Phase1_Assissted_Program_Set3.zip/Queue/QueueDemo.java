package DatastructurePrograms;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<String> q=new LinkedList<String>();
		q.add("Apple");
		q.add("Orange");
		q.add("Grape");
		q.add("Watermelon");
		q.add("Muskmelon");
		
		System.out.println("\nElement in Queue: "+q);
		Scanner s=new Scanner(System.in);
		System.out.println("\nQueue Size: "+q.size());
		System.out.println("\nEnter the Fruit You want to Remove");
		String str=s.next();
		System.out.println("\nQueue Size: "+q.size());
		if(q.contains(str))
		{
		q.remove(str);
		}
		else{
			System.out.println("\nEntered Fruit is not present in Queue");
		}
		System.out.println("\nElements in Queue After Remove Operation: "+q);
		
		

	}

}
