package DatastructurePrograms;

import java.util.Iterator;
import java.util.LinkedList;

public class linkedlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> li=new LinkedList<String>();
		li.add("First");
		li.add("Second");
		li.add("Third");
		li.add("Fourth");
		li.add("Fifth");
		li.add("Second");
		
		Iterator it=li.iterator();
		System.out.println("\nElements in Linked List");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		li.removeFirstOccurrence("Second");
		System.out.println("\nAfter Removing First Occurence Of Second "+li);
		
		li.removeFirst();
		System.out.println("\nAfter Removing First Element in linked list"+" "+li);
		
		li.removeLast();
		System.out.println("\nAfter Removing Last Element in linked list"+" "+li);
		
		it=li.descendingIterator();
		System.out.println("\nAfter Reversing linked list elements are");
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		

	}

}
