package DatastructurePrograms;

import java.util.Scanner;

public class Range_queries {
	
	static void range(int arr[],int l, int r)
	{
		int sum=0;
		while(l<=r){
			sum+=arr[l];
			l++;
		}
		System.out.println("\nAfter adding the elements: "+sum);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the Array Elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		
		range(arr,0,5);
		range(arr,3,5);
		range(arr,2,4);

	}

}
