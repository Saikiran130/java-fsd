package Phase2_servlet.programs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Phase2_servlet.programs.DatabaseConnection;

/**
 * Servlet implementation class Productdb
 */
@WebServlet("/Productdb")
public class Productdb extends HttpServlet {
	private static final String url = "jdbc:mysql://localhost:3306/db_world";
    private static final String user = "root";
    private static final String password = "root";
    
    Connection con;
    PreparedStatement prSt;
    Statement stmt;
    ResultSet rs;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Productdb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 try {
			  
	            // Initialize the database
	            Connection con = DatabaseConnection.initializeDatabase();
	  
	            // Create a SQL query to insert data into demo table
	            // demo table consists of two columns, so two '?' is used
	            PreparedStatement st = con
	                   .prepareStatement("select * from product where prodid=?");
	  
	            // For the first parameter,
	            // get the data using request object
	            // sets the data to st pointer
	            st.setInt(1, Integer.valueOf(request.getParameter("prodid")));
	 
	  
	            // Execute the insert command using executeUpdate()
	            // to make changes in database
	            st.executeQuery();
	  
	  
	            // Get a writer pointer 
	            // to display the successful result
	            PrintWriter out = response.getWriter();
	            String query="Select * from product where prodid=2";
	            stmt = con.createStatement();
	            rs=stmt.executeQuery(query);
	            System.out.println("\nRetrieving only 2nd product from the product table");
	            System.out.println();
	            
	            while (rs.next()) {
	               int prodid = rs.getInt("prodid");
	               String prodname = rs.getString("prodname");
	               int price = rs.getInt("price");
	               int modelyear=rs.getInt("modelyear");
	               System.out.println("ProductId: "+prodid + "  "+"ProductName: " + prodname+"  "+"Price: "+price+"  "+" Modelyear: "+modelyear);
	            }    
	            out.println("<html><body><b>Rows Retrieved"
	                        + "</b></body></html>");
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}


