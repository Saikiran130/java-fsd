package Longest_Increasing_Subsequence;

import java.util.Arrays;
import java.util.Scanner;

public class Increasing_Subsequence {
	 
	 static int long_incre_subseq(int arr[])
	 {
		 if(arr.length==1)
			 return arr.length;
		 
		 int res[]=new int[arr.length];
		 int max=-1;
		 Arrays.fill(res,1);
		 for(int i=1;i<arr.length;i++)
		 {
			 for(int j=0;j<i;j++)
			 {
				 if(arr[j]<arr[i])
				 {
					 res[i]=Math.max(res[i], res[j]+1);
				 }
			 }
			 max=Math.max(max,res[i]);
		 }
		 return max;
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\nEnter the size of array");
		int n=s.nextInt();
		int arr[]=new int[n];
		System.out.println("\nEnter the Array Elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=s.nextInt();
		}
		int result=long_incre_subseq(arr);
		System.out.println("Length of Longest Increasing SubSequence: "+result);

	}

}
