package com.example.Driveyourway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneDriveyourwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
