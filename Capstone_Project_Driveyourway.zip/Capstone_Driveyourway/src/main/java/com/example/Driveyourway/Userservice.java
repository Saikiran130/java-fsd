package com.example.Driveyourway;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Userservice {
	
	@Autowired
	private Userrepo repo;
	
	public User insert(User u)
	{
		return repo.save(u);
	}
	
	public User findusername(String name)
	{
		return repo.findByusername(name);
	}
	
	public User findpassword(String pass)
	{
		return repo.findBypassword(pass);
	}
	
	public List<User> listallusers()
	{
		return repo.findAll();
	}
	
	@Transactional
	public String deleteuser(String username)
	{
		repo.deleteByusername(username);
		return "username "+username+" is deleted";
	}
	
	public User updateuser(User u)
	{
		return repo.save(u);
	}
	

}
