package com.example.Driveyourway;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class booking {
	
	private String carName;
	private String model;
	private String color;
	private int year;
	private String engine;
	private String brand;
	private String ownerName;
	@Id
	private String ownerContact;
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	

	public String getOwnerContact() {
		return ownerContact;
	}
	public void setOwnerContact(String ownerContact) {
		this.ownerContact = ownerContact;
	}
	booking()
	{
		
	}
	public booking(String carName, String model, String color, int year, String engine, String brand, String ownerName,
			String ownerContact) {
		super();
		this.carName = carName;
		this.model = model;
		this.color = color;
		this.year = year;
		this.engine = engine;
		this.brand = brand;
		this.ownerName = ownerName;
		this.ownerContact = ownerContact;
	}
	@Override
	public String toString() {
		return "Cardetails [carName=" + carName + ", model=" + model + ", color=" + color + ", year=" + year
				+ ", engine=" + engine + ", brand=" + brand + ", ownerName=" + ownerName + ", ownerContact="
				+ ownerContact + "]";
	}
	

}
