package com.example.Driveyourway;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Admincontroller {
	
	@Autowired
	private Adminservice service;
	
	@Autowired
	private Cardetailsservice carservice;
	
	@Autowired
	private Userservice usrserv;
	
	@Autowired
	private bookingservice bserv;
	
	
	@RequestMapping("/Registeradmin")
	public ModelAndView Adminregister(HttpServletRequest req, HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		Admin a=new Admin();
		String user=req.getParameter("username");
		String pass=req.getParameter("password");
		a.setUsername(user);
		a.setPassword(pass);
		if(service.findadminname(user)==null && service.findadminpassword(pass)==null)
		{
			Admin aa=service.Registeradmin(a);
			if(aa!=null) {
			mv.setViewName("/adminlogin");
			}
		}
		return mv;
	}
	
	@RequestMapping("/adminlogin")
	public ModelAndView AdminLogin(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		String user= request.getParameter("username");
		String pass= request.getParameter("password");
		if((service.findadminname(user)!=null)&&(service.findadminpassword(pass)!=null)) {
		
				mv.setViewName("Adminoper.jsp");
		
		}
		return mv;
		
	}
	
	@RequestMapping("/Registeruser")
	public ModelAndView Userregister(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		User u=new User();
		String usr=req.getParameter("username");
		String pass=req.getParameter("password");
		u.setUsername(usr);
		u.setPassword(pass);
		
		if(usrserv.findusername(usr)==null && usrserv.findpassword(pass)==null)
		{
			User uu=usrserv.insert(u);
			if(uu!=null) {
			mv.setViewName("/userlogin");
			}
		}
		return mv;
	}
	
	@RequestMapping("/userlogin")
	public ModelAndView LoginUser(HttpServletRequest req, HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		String user=req.getParameter("username");
		String pass=req.getParameter("password");
		if(usrserv.findusername(user)!=null && usrserv.findpassword(pass)!=null)
		{
			mv.setViewName("/getallusercars");
		}
		
		return mv;
	}
	
	@PostMapping("/insertcardetails")
	public Cardetails insertcar(@RequestBody Cardetails cdetails)
	{
		return carservice.insertcardetails(cdetails);
	}
	
	@RequestMapping("/insertcar")
	public ModelAndView Addcardetails(HttpServletRequest req, HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		Cardetails cd=new Cardetails();
		cd.setCarName(req.getParameter("carname"));
		cd.setModel(req.getParameter("model"));
		cd.setColor(req.getParameter("color"));
		cd.setYear(Integer.parseInt(req.getParameter("year")));
		cd.setEngine(req.getParameter("engine"));
		cd.setBrand(req.getParameter("brand"));
		cd.setOwnerName(req.getParameter("owname"));
		cd.setOwnerContact(req.getParameter("owno"));
		
		Cardetails cc=carservice.insertcardetails(cd);
		if(cc!=null)
		{
			mv.setViewName("/getallcars");
		}
		
		return mv;
	}
	
	@RequestMapping("/getallusercars")
	public ModelAndView displaycars(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		List<Cardetails> carlist=carservice.getallcars();
		mv.setViewName("displaycarsuser.jsp");
		mv.addObject("list", carlist);
		return mv;
		
	}
	
	@RequestMapping("/buycar")
	public ModelAndView book(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		booking b=new booking();
		String ownercontact=req.getParameter("owno");
		if(bserv.findowner(ownercontact)==null) {
		Cardetails b1=carservice.findcarowner(ownercontact);
		b.setOwnerContact(req.getParameter("owno"));
		booking bb=bserv.insert(b);
		
		if(bb!=null && bserv.findowner(ownercontact)==null)
		{
			List<Cardetails> blist=new ArrayList<Cardetails>();
			blist.add(b1);
			mv.setViewName("confirmbooked.jsp");
			mv.addObject("boookedcar", blist);
		}
		}
		return mv;
		
		
		
	}

	
	@RequestMapping("/editcar")
	public ModelAndView editcardetails(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		Cardetails cd=new Cardetails();
		String ownercontact=req.getParameter("owno");
		if(carservice.findcarowner(ownercontact)!=null) {
		cd.setCarName(req.getParameter("carname"));
		cd.setModel(req.getParameter("model"));
		cd.setColor(req.getParameter("color"));
		cd.setYear(Integer.parseInt(req.getParameter("year")));
		cd.setEngine(req.getParameter("engine"));
		cd.setBrand(req.getParameter("brand"));
		cd.setOwnerName(req.getParameter("owname"));
		cd.setOwnerContact(req.getParameter("owno"));
		
		Cardetails cc=carservice.updatcar(cd);
		
		if(cc!=null)
		{
			System.out.println("================================");
			System.out.println("Car Details Updated");
			mv.setViewName("/getallcars");
		}
		}
		
		return mv;
		
		
		
	}
	
	
	
	@RequestMapping("/Registeruser1")
	public ModelAndView Userregister1(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		User u=new User();
		String usr=req.getParameter("username");
		String pass=req.getParameter("password");
		u.setUsername(req.getParameter("username"));
		u.setPassword(req.getParameter("password"));
		
		if(usrserv.findusername(usr)==null && usrserv.findpassword(pass)==null)
		{
			User uu=usrserv.insert(u);
			if(uu!=null) {
			mv.setViewName("/getallusers");
			}
		}
		return mv;
	}
	
	@RequestMapping("/updateuser")
	public ModelAndView updateuser(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		User u=new User();
		String user=req.getParameter("username");
		String pass=req.getParameter("pass");
		if(usrserv.findusername(user)!=null && usrserv.findusername(pass)!=null)
		{
			u.setUsername(user);
			u.setPassword(pass);
			User uu=usrserv.updateuser(u);
			mv.setViewName("/getallusers");
		}
		return mv;
	}
	
	
	@RequestMapping("/getallusers")
	public ModelAndView listofusers(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		User u=new User();
		List<User> listusers=usrserv.listallusers();
		mv.setViewName("displayallusers.jsp");
		mv.addObject("list", listusers);
		return mv;
	}
	
	@RequestMapping("/getallcars")
	public ModelAndView listofcars(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		List<Cardetails> listcars=carservice.getallcars();
		mv.setViewName("displayallcars.jsp");
		mv.addObject("list", listcars);
		return mv;
		
	}
	
	@RequestMapping("/deletecar")
	public ModelAndView deletecardet(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		Cardetails cd=new Cardetails();
		String ownercont=req.getParameter("owno");
		cd.setOwnerContact(req.getParameter("owno"));
		carservice.deletecar(ownercont);
		mv.setViewName("/getallcars");
		return mv;
		
		
	}
	
	@RequestMapping("/deleteuser")
	public ModelAndView deleteuserdetails(HttpServletRequest req,HttpServletResponse res)
	{
		ModelAndView mv=new ModelAndView();
		User u=new User();
		String user=req.getParameter("username");
		u.setUsername(user);
		usrserv.deleteuser(user);
		mv.setViewName("/getallusers");
		return mv;
	}
	
	
}
