package com.example.Driveyourway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Adminservice {
	
	@Autowired
	private Adminrepo repo;

	
	public Admin Registeradmin(Admin a)
	{
		return repo.save(a);
	}
	
	public Admin findadminname(String str)
	{
		return repo.findByusername(str);
	}
	
	public Admin findadminpassword(String pass)
	{
		return repo.findBypassword(pass);
	}

}
