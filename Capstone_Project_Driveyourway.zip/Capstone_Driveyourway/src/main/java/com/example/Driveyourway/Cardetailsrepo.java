package com.example.Driveyourway;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Cardetailsrepo  extends JpaRepository<Cardetails, Integer> {
	
	public String deleteByownerContact(String contact);
	public Cardetails findByownerContact(String cont);

}
