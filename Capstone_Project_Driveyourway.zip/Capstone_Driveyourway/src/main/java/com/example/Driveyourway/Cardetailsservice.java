package com.example.Driveyourway;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Cardetailsservice {
	
	@Autowired
	private Cardetailsrepo repo;
	
	public Cardetails insertcardetails(Cardetails cdet)
	{
		return repo.save(cdet);
	}
	
	public List<Cardetails> insertallcardet(List<Cardetails> cdet1){
		return repo.saveAll(cdet1);
	}

	public List<Cardetails> getallcars()
	{
		return repo.findAll();
	}
	
	public Cardetails updatcar(Cardetails cd)
	{
		return repo.save(cd);
	}
	
	public Cardetails findcarowner(String ownerno)
	{
		return repo.findByownerContact(ownerno);
	}
	
	@Transactional
	public String deletecar(String cont)
	{
		repo.deleteByownerContact(cont);
		return "Deleted this Cardetails "+cont;
	}
}
