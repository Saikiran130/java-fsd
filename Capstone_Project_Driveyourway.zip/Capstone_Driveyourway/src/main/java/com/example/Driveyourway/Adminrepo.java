package com.example.Driveyourway;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface Adminrepo extends JpaRepository<Admin, Integer> {
	@Query("select admin from Admin admin where admin.username=?1")
	public Admin findByusername(String name);
	
	public Admin findBypassword(String pwd);
}
