package com.example.Driveyourway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneDriveyourwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneDriveyourwayApplication.class, args);
	}

}
