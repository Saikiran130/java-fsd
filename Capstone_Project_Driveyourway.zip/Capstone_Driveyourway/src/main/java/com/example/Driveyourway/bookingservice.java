package com.example.Driveyourway;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class bookingservice {
	
	@Autowired
	private bookingrepo repo;
	
	public booking insert(booking b)
	{
		return repo.save(b);
	}
	
	public booking findowner(String owncont)
	{
		return repo.findByownerContact(owncont);
	}

}
