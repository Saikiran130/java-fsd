package com.example.SpringJunit;


public class Authenticate {
	
	
	public String authenticate_login(String user, String password)
	{
		
		if((user.equals("Sai"))&&(password.equals("Sai@123")))
		{
			return "Login Successfull";
		}
		return "Login Failed";
	}
	
	public String authenticate_login1(String user, String password)
	{
		
		if((user.equals("Harry"))&&(password.equals("Harry007")))
		{
			return "Login Successfull";
		}
		return "Login Failed";
	}
	
	
	
	

}
