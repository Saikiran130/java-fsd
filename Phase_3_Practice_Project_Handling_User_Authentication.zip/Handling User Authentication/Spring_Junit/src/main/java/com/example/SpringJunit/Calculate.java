package com.example.SpringJunit;

public class Calculate {
	
	int add(int a, int b) {
	return a+b;
	}

}
