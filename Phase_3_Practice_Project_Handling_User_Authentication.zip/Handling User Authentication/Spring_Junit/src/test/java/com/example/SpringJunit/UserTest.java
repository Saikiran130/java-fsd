package com.example.SpringJunit;

import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class UserTest  {
UserAuthentication auth;
	
	@BeforeEach
	public void BeforeAll()
	{
		auth=new UserAuthentication();
		System.out.println("Authentication object created");
	}
	
	@Test
	public void testcase1()
	
	{
		Assertions.assertEquals("Login Successfull", auth.authenticate_login("Priya","riya@21"));
		System.out.println("TestCase1");
		
	}
	@Test
	public void testcase2()
	{
		Assertions.assertEquals("Invalid", auth.authenticate_login("riya","riya@S21"));
		System.out.println("TestCase2");
		
	}
	@AfterEach
	public void AfterAll() {
		auth=null;
		System.out.println("Authentication object Removed");
		
	}
}