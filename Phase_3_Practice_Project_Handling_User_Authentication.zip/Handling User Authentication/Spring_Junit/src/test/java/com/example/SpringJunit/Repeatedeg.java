package com.example.SpringJunit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class Repeatedeg {
	
	Calculate c;
	
	@BeforeEach
	void initEach()
	{
		c=new Calculate();
	}
	
	@Test
	@RepeatedTest(1000)
	void test_calculate()
	{
		int a=1;
		int b=1;
		
		int expected=2;
		
		int actual=c.add(a, b);
		
		Assertions.assertEquals(expected, actual);
	}
	

}
